lane c: baseline
