# Disposable infrastructure lane overlap

Status: open
Blocked by: None
Triage: ready-for-agent
Type: task

Only the reviewed tiny fixture and scoped Rust gate are permitted. No production or gameplay work.
