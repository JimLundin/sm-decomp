# Worker handoff: lane-a attempt 1

Typed authority: `/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/decomp-parallel/sessions/01a13515-9a51-7af3-bc9f-a144afb06090/lane-a-1.toml`; sequence: `3`.
Session: `01a13515-9a51-7af3-bc9f-a144afb06090`; worker thread: `01a13516-6585-7ec0-b595-9497da55323f`; agent: `worker-a`.
Claim: `(lane-a, e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322, 1, drill-a)`.
Source commit: `c92f401ce232fbfcc412021df14c9adedbedc057`; baseline: `2087370d8c7c0b8d8e0b2c613a2681d34f490e9d`.
Worktree: `/tmp/sm-concurrency-drill-retry-lane-a-1`.
Cleanup: `pending`.

```toml
schema = "decomp-worker-handoff-v1"
sequence = 3
session_id = "01a13515-9a51-7af3-bc9f-a144afb06090"
worker_session_id = "01a13516-6585-7ec0-b595-9497da55323f"
agent = "worker-a"
authority_generation = 2
effort = "concurrency-drill-retry"
baseline = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
branch = "concurrency-drill-retry-lane-a-1"
worktree = "/tmp/sm-concurrency-drill-retry-lane-a-1"
source_commit = "c92f401ce232fbfcc412021df14c9adedbedc057"
runs = []
evidence = []
stages = []
limitations = ["isolated infrastructure drill owned by drill-a; no gameplay"]

[claim]
id = "lane-a"
revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322"
attempt = 1
coordinator = "drill-a"

[job]
id = "lane-a"
revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322"
kind = "implement"
subject = "Disposable lane a"
writable_paths = ["docs/drill-a.md"]
blockers = []
instructions = "Append one scoped WIP lane statement; retain source and handoff; infrastructure-only drill."
ticket = ".scratch/concurrency-drill-retry/issues/a.md"

[job.inputs]
admission-domain = "infrastructure-v1"
base-head = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
infrastructure-scope-file = "/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/drill-control/scope-a.toml"
infrastructure-scope-sha256 = "e6c70bd582b67ca024d20e362c9a44efb8f40f103a3aa20dc6f0a735d7ab5738"

[[processes]]
pid = 503608
boot_id = "7119fcce-5593-4526-aa9b-07127767c4ef"
start_ticks = 2835204
argv = [
    "codex",
    "exec",
    "-s",
    "danger-full-access",
    "-C",
    "/tmp/sm-decomp-concurrency-drill-retry-20261013",
    "--json",
    "-",
]
cwd = "/tmp/sm-decomp-concurrency-drill-retry-20261013"
observed_at = "1791892022"
status = "running"

[[dependencies]]
path = "/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/decomp-parallel/sessions/01a13515-9a51-7c73-9913-1deb499ba15c/lane-a-1.toml"
sha256 = "9317dca205c7830150246197a04e1a0e19ff8b250cb15addc8796d2a995b4194"

[[dependencies]]
path = "/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/drill-control/drill-a-generation-1-transfer.toml"
sha256 = "bbe8d546fd121511d835ef0b8fbc7e8ceb6d98674bdb566893d5e0e3355fe348"

[[dependencies]]
path = "/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/drill-control/drill-a-lane-a-1-child-proof.toml"
sha256 = "92578e11ce21c0fca1572710bbcd1f71e7407a17e3d51ab0543185812751f9f4"

[cleanup]
status = "pending"
reclaimed_bytes = 0
receipts = []
retained_dependencies = []
remaining_action = "scoped cleanup after writers stop"

[next]
cwd = "/tmp/sm-concurrency-drill-retry-lane-a-1"
argv = [
    "cargo",
    "test",
    "--locked",
    "--offline",
]
timeout_seconds = 60

[next.env]
SM_PIPELINE_ROOT = "/tmp/sm-decomp-concurrency-drill-retry-20261013/out/pipeline"
SM_PIPELINE_WORKERS = "4"

```
