# Worker handoff: lane-a attempt 2

Typed authority: `/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/decomp-parallel/sessions/01a13515-9a51-7af3-bc9f-a144afb06090/lane-a-2.toml`; sequence: `2`.
Session: `01a13515-9a51-7af3-bc9f-a144afb06090`; worker thread: `01a1351b-56be-7150-b777-9a2be1424502`; agent: `worker-a-replacement`.
Claim: `(lane-a, e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322, 2, drill-a)`.
Source commit: `0812fbcd0857b6845f2ef966f6b2f601c0b4a949`; baseline: `2087370d8c7c0b8d8e0b2c613a2681d34f490e9d`.
Worktree: `/tmp/sm-concurrency-drill-retry-lane-a-2`.
Cleanup: `pending`.

```toml
schema = "decomp-worker-handoff-v1"
sequence = 2
session_id = "01a13515-9a51-7af3-bc9f-a144afb06090"
worker_session_id = "01a1351b-56be-7150-b777-9a2be1424502"
agent = "worker-a-replacement"
authority_generation = 2
effort = "concurrency-drill-retry"
baseline = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
branch = "concurrency-drill-retry-lane-a-2"
worktree = "/tmp/sm-concurrency-drill-retry-lane-a-2"
source_commit = "0812fbcd0857b6845f2ef966f6b2f601c0b4a949"
runs = []
evidence = []
dependencies = []
stages = []
limitations = ["isolated infrastructure drill owned by drill-a; no gameplay"]

[claim]
id = "lane-a"
revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322"
attempt = 2
coordinator = "drill-a"

[job]
id = "lane-a"
revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322"
kind = "implement"
subject = "Disposable lane a"
writable_paths = ["docs/drill-a.md"]
blockers = []
instructions = "Append one scoped WIP lane statement; retain source and handoff; infrastructure-only drill."
ticket = ".scratch/concurrency-drill-retry/issues/a.md"

[job.inputs]
admission-domain = "infrastructure-v1"
base-head = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
infrastructure-scope-file = "/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/drill-control/scope-a.toml"
infrastructure-scope-sha256 = "e6c70bd582b67ca024d20e362c9a44efb8f40f103a3aa20dc6f0a735d7ab5738"

[[processes]]
pid = 506472
boot_id = "7119fcce-5593-4526-aa9b-07127767c4ef"
start_ticks = 2867595
argv = [
    "codex",
    "exec",
    "-s",
    "danger-full-access",
    "-C",
    "/tmp/sm-decomp-concurrency-drill-retry-20261013",
    "--json",
    "-",
]
cwd = "/tmp/sm-decomp-concurrency-drill-retry-20261013"
observed_at = "1791892346"
status = "running"

[cleanup]
status = "pending"
reclaimed_bytes = 0
receipts = []
retained_dependencies = []
remaining_action = "scoped cleanup after writers stop"

[next]
cwd = "/tmp/sm-concurrency-drill-retry-lane-a-2"
argv = [
    "cargo",
    "test",
    "--locked",
    "--offline",
]
timeout_seconds = 60

[next.env]
SM_PIPELINE_ROOT = "/tmp/sm-decomp-concurrency-drill-retry-20261013/out/pipeline"
SM_PIPELINE_WORKERS = "4"

```
