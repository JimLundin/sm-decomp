# Worker handoff: integrate-lane-a attempt 1

Typed authority: `/tmp/sm-decomp-concurrency-drill-retry-20261013/.scratch/decomp-parallel/sessions/01a13515-9a51-7c73-9913-1deb499ba15c/integrate-lane-a-1.toml`; sequence: `1`.
Session: `01a13515-9a51-7c73-9913-1deb499ba15c`; worker thread: `01a1351e-7d86-7013-a85a-60a585fc247a`; agent: `integration-worker`.
Claim: `(integrate-lane-a, e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322-2, 1, drill-integrator)`.
Source commit: `2087370d8c7c0b8d8e0b2c613a2681d34f490e9d`; baseline: `2087370d8c7c0b8d8e0b2c613a2681d34f490e9d`.
Worktree: `/tmp/sm-decomp-concurrency-drill-retry-20261013`.
Cleanup: `pending`.

```toml
schema = "decomp-worker-handoff-v1"
sequence = 1
session_id = "01a13515-9a51-7c73-9913-1deb499ba15c"
worker_session_id = "01a1351e-7d86-7013-a85a-60a585fc247a"
agent = "integration-worker"
authority_generation = 1
effort = "concurrency-drill-retry"
baseline = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
worktree = "/tmp/sm-decomp-concurrency-drill-retry-20261013"
source_commit = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
submitted_commit = "0812fbcd0857b6845f2ef966f6b2f601c0b4a949"
runs = []
evidence = []
dependencies = []
stages = []
limitations = ["isolated infrastructure drill owned by drill-integrator; no gameplay"]

[claim]
id = "integrate-lane-a"
revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322-2"
attempt = 1
coordinator = "drill-integrator"

[job]
id = "integrate-lane-a"
revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322-2"
kind = "integrate"
subject = "Integrate Disposable lane a"
writable_paths = ["docs/drill-a.md"]
blockers = []
instructions = "Integrate submitted Translation scope Disposable lane a from its isolated worktree. Freeze merged source, run required verification, authenticate evidence and finish scoped cleanup before recording integrated completion."

[job.inputs]
base-head = "2087370d8c7c0b8d8e0b2c613a2681d34f490e9d"
submission-attempt = "2"
submission-id = "lane-a"
submission-revision = "e0ca4a38af1c6ba76aa26bc85ff2e61afe6d37f5da2198ac4bac86df33894322"

[[processes]]
pid = 509273
boot_id = "7119fcce-5593-4526-aa9b-07127767c4ef"
start_ticks = 2888243
argv = [
    "codex",
    "exec",
    "-s",
    "danger-full-access",
    "-C",
    "/tmp/sm-decomp-concurrency-drill-retry-20261013",
    "--json",
    "-",
]
cwd = "/tmp/sm-decomp-concurrency-drill-retry-20261013"
observed_at = "1791892553"
status = "running"

[cleanup]
status = "pending"
reclaimed_bytes = 0
receipts = []
retained_dependencies = []
remaining_action = "scoped cleanup after writers stop"

[next]
cwd = "/tmp/sm-decomp-concurrency-drill-retry-20261013"
argv = [
    "cargo",
    "test",
    "--locked",
    "--offline",
]
timeout_seconds = 60

[next.env]
SM_PIPELINE_ROOT = "/tmp/sm-decomp-concurrency-drill-retry-20261013/out/pipeline"
SM_PIPELINE_WORKERS = "4"

```
