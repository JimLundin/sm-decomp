use std::{env, fs};
fn main() {
    let paths = env::args().skip(1).collect::<Vec<_>>();
    let original = fs::read(&paths[0]).unwrap();
    let runtime = fs::read(&paths[1]).unwrap();
    let mut begin = None;
    let mut total = 0;
    for i in 0..original.len() {
        if original[i] != runtime[i] {
            total += 1;
            begin.get_or_insert(i);
        } else if let Some(start) = begin.take() {
            let address = |v: usize| 0x808000u32 + ((v / 0x8000) as u32 * 0x10000) + (v % 0x8000) as u32;
            println!("{start:06x}..{i:06x} {:06x}..{:06x}", address(start), address(i - 1));
        }
    }
    println!("original={} runtime={} changed={total}", original.len(), runtime.len());
}
