use std::{
    fs,
    path::PathBuf,
    process::Command,
    time::{SystemTime, UNIX_EPOCH},
};

struct Scratch(PathBuf);
impl Scratch {
    fn new() -> Self {
        let unique = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let path = std::env::temp_dir().join(format!("sm-live-whole-controls-{}-{unique}", std::process::id()));
        fs::create_dir(&path).unwrap();
        Self(path)
    }
}
impl Drop for Scratch {
    fn drop(&mut self) {
        if !std::thread::panicking() {
            fs::remove_dir_all(&self.0).unwrap();
        } else {
            eprintln!("retained whole-Ridley control failure: {}", self.0.display());
        }
    }
}

#[test]
fn whole_c_bridge_controls_refusal_errors_nested_ownership_mode7_and_projectile_captures() {
    let scratch = Scratch::new();
    let host = include_str!("../src/live_ridley_subsystem_host.c.in")
        .replace("__PPU_CONTRACT__", "#define RIDLEY_PPU_BYTES 4\nstatic int RidleyPpuContractSave(uint8 *b){memset(b,0,RIDLEY_PPU_BYTES);return 1;}")
        .replace("__AUDIO_WRAPPERS__", "PORT_WHOLE_AUDIO(QueueSfx2_Max6,1,6)");
    let source = format!(
        r#"
#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
typedef uint8_t uint8;typedef uint16_t uint16;typedef uint32_t uint32;typedef int16_t int16;typedef int32_t int32;
static uint8 g_ram[131072],g_rom[8];static struct{{struct{{unsigned romSize;}}*cart;}}snes;static typeof(snes)*g_snes=&snes;
static uint16 native_host[8];static FILE *port_effects;static int port_mixed=1;static unsigned snes_frame_counter;
static int support_answer,execute_answer,native_calls,abi_execute_calls,projectile_abi_calls;
static int nested,forbid_native;static unsigned event_count,bus_count;static uint32 bus[8][3];
static uint16 GET_WORD(const uint8*p){{return p[0]|((uint16)p[1]<<8);}}
static void PUT_WORD(uint8*p,uint16 v){{p[0]=v;p[1]=v>>8;}}
static void PortEffect(FILE*f,const char*format,...){{event_count++;va_list a;va_start(a,format);vfprintf(f,format,a);va_end(a);fflush(f);}}
void PortWholeBus(uint32,uint32,uint32);
enum{{M7A=0x211b,M7B=0x211c,MPYM=0x2135}};
static void WriteReg(uint32 a,uint8 v){{assert(bus_count<8);bus[bus_count][0]=1;bus[bus_count][1]=a;bus[bus_count++][2]=v;PortWholeBus(1,a,v);}}
static uint8 ReadReg(uint32 a){{uint8 v=a==MPYM?0x34:0x12;assert(bus_count<8);bus[bus_count][0]=0;bus[bus_count][1]=a;bus[bus_count++][2]=v;PortWholeBus(0,a,v);return v;}}
void PortProjectileHostSave(uint16*w){{memcpy(w,native_host,sizeof(native_host));}}
void PortProjectileHostLoad(const uint16*w){{memcpy(native_host,w,sizeof(native_host));}}
void PortC_SpawnEprojWithRoomGfx(uint16 a,uint16 b){{(void)a;(void)b;assert(!"unexpected native projectile retry");}}
void PortC_SpawnEprojWithGfx(uint16 a,uint16 b,uint16 c){{(void)a;(void)b;(void)c;assert(!"unexpected native projectile retry");}}
void PortC_EprojRunAll(void){{assert(!"unexpected native projectile retry");}}
int32 port_native_projectile(uint8*a,size_t b,const uint8*c,size_t d,uint16*e,size_t f,uint16 g,uint16 h,uint32 i){{(void)a;(void)b;(void)c;(void)d;(void)e;(void)f;(void)g;(void)h;(void)i;projectile_abi_calls++;return 0;}}
{projectile}
{host}
uint32 port_ridley_subsystem_live_controls(void){{return 10;}}
int32 port_ridley_subsystem_live(uint8*ram,size_t len,const uint8*rom,size_t rom_len,uint16*words,size_t count,uint32 root,uint32 execute){{
 (void)rom;assert(len==sizeof(g_ram)&&rom_len==8&&count==8&&root<16);
 if(!execute)return support_answer;
 abi_execute_calls++;ram[0]=91;words[7]=99;
 return execute_answer;
}}
uint16 PortC_SpawnEnemy(uint8 a,uint16 b){{(void)a;(void)b;return 64;}}
void PortC_EnemyDeathAnimation(uint16 a,uint16 b){{(void)a;(void)b;}}
void PortC_Enemy_ItemDrop_Ridley(uint16 a){{(void)a;}}
void PortC_NormalEnemyTouchAiSkipDeathAnim_CurEnemy(void){{}}
void PortC_NormalEnemyShotAiSkipDeathAnim_CurEnemy(void){{}}
void PortC_NormalEnemyPowerBombAiSkipDeathAnim_CurEnemy(void){{}}
uint16 PortC_CallSomeSamusCode(uint16 a){{return a;}}
void PortC_QueueMusic_Delayed8(uint16 a){{(void)a;}}
void PortC_QueueSfx2_Max6(uint16 a){{(void)a;}}
static void NativeLeaf(void){{native_calls++;g_ram[1]++;}}
static void NativeRoot(void){{if(forbid_native){{fprintf(stderr,"C retry occurred\n");exit(17);}}native_calls++;g_ram[0]++;if(nested)PortWholeRidleyRoot(1,NativeLeaf);}}
static void CheckAllocationCapture(const char*phase,uint16 slot_id,uint16 host_last){{
 char name[120];uint8 bytes[131072];snprintf(name,sizeof(name),"fixtures/projectile-allocation-9642-001-%s.wram",phase);
 FILE*f=fopen(name,"rb");assert(f&&fread(bytes,1,sizeof(bytes),f)==sizeof(bytes)&&fclose(f)==0);
 assert(GET_WORD(bytes+0x1995)==0x000e&&GET_WORD(bytes+0x1997+34)==slot_id);
 uint8 words[16];snprintf(name,sizeof(name),"fixtures/projectile-allocation-9642-001-%s.host",phase);f=fopen(name,"rb");assert(f&&fread(words,1,16,f)==16&&fclose(f)==0);assert(GET_WORD(words+14)==host_last);
}}
int main(int argc,char**argv){{
 assert(argc==2);typeof(*snes.cart)cart={{8}};snes.cart=&cart;port_effects=fopen("effects.log","wb");assert(port_effects);port_whole_services=tmpfile();assert(port_whole_services);
 if(!strcmp(argv[1],"support-error")){{forbid_native=1;support_answer=-1;PortWholeRidleyRoot(0,NativeRoot);return 19;}}
 if(!strcmp(argv[1],"accepted-error")){{forbid_native=1;support_answer=0;execute_answer=-1;PortWholeRidleyRoot(0,NativeRoot);return 19;}}
 if(!strcmp(argv[1],"refusal-nesting")){{
  support_answer=-2;nested=1;PortWholeRidleyRoot(0,NativeRoot);
  assert(native_calls==2&&abi_execute_calls==0&&g_ram[0]==1&&g_ram[1]==1);
  assert(port_whole_total[0]==1&&port_whole_c[0]==1&&port_whole_refused[0]==1&&port_whole_admitted[0]==0&&port_whole_total[1]==0&&port_whole_depth==0&&port_whole_supported==0);
 }}else if(!strcmp(argv[1],"accepted-success")){{
  support_answer=0;PortWholeRidleyRoot(0,NativeRoot);
  assert(native_calls==0&&abi_execute_calls==1&&g_ram[0]==91&&native_host[7]==99);
  assert(port_whole_total[0]==1&&port_whole_rust[0]==1&&port_whole_c[0]==0&&port_whole_admitted[0]==1&&port_whole_refused[0]==0&&port_whole_depth==0&&port_whole_supported==0);
 }}else if(!strcmp(argv[1],"mode7-order")){{
  port_whole_depth=1;assert(PortWholeRidleyMode7(-257,0x80)==0x1234);assert(bus_count==5);
  const uint32 expected[5][3]={{{{1,M7A,0xff}},{{1,M7A,0xfe}},{{1,M7B,0x80}},{{0,MPYM,0x34}},{{0,MPYM+1,0x12}}}};
  assert(!memcmp(bus,expected,sizeof(expected))&&event_count==5);port_whole_depth=0;
 }}else if(!strcmp(argv[1],"allocation-capture")){{
  port_whole_depth=1;PUT_WORD(g_ram+0x1995,0x000e);native_host[7]=77;
  PortWholeRidleyAllocation(0,0x9642,0x000e,0xffff);
  assert(port_projectile_alloc_total[0]==1&&port_projectile_total[0]==0&&port_projectile_alloc_rust[0]==0);
  CheckAllocationCapture("before",0,77);
  PUT_WORD(g_ram+0x1997+34,0x9642);native_host[7]=88;
  PortWholeRidleyAllocation(1,0x9642,0x000e,34);
  assert(port_projectile_total[0]==1&&port_projectile_rust[0]==1&&port_projectile_c[0]==0&&port_projectile_active_rust[0]==1&&port_projectile_9642_rust[0]==1&&port_projectile_alloc_rust[0]==1);
  assert(projectile_abi_calls==0);CheckAllocationCapture("after",0x9642,88);
  // Saturation still counts an accepted allocation attempt, with no material allocation.
  for(unsigned k=0;k<36;k+=2)PUT_WORD(g_ram+0x1997+k,0x9650);
  PortWholeRidleyAllocation(0,0x9642,0,0xffff);PortWholeRidleyAllocation(1,0x9642,0,0xffff);
  assert(port_projectile_total[0]==2&&port_projectile_rust[0]==2&&port_projectile_active_rust[0]==1&&port_projectile_alloc_total[0]==1&&port_projectile_alloc_rust[0]==1);
  assert(port_projectile_refused[0]==0&&projectile_abi_calls==0);port_whole_depth=0;
 }}else{{return 18;}}
 assert(fclose(port_whole_services)==0&&fclose(port_effects)==0);return 0;
}}
"#,
        projectile = include_str!("../src/live_projectile_host.c.in"),
    );
    fs::write(scratch.0.join("control.c"), source).unwrap();
    let compile = Command::new("cc")
        .args(["-std=gnu11", "-O0", "-Wall", "-Wno-unused-function"])
        .arg(scratch.0.join("control.c"))
        .arg("-o")
        .arg(scratch.0.join("control"))
        .output()
        .unwrap();
    assert!(compile.status.success(), "{}", String::from_utf8_lossy(&compile.stderr));
    for mode in
        ["refusal-nesting", "accepted-success", "support-error", "accepted-error", "mode7-order", "allocation-capture"]
    {
        let run = scratch.0.join(mode);
        fs::create_dir_all(run.join("fixtures")).unwrap();
        let output = Command::new(scratch.0.join("control")).arg(mode).current_dir(&run).output().unwrap();
        let effects = fs::read_to_string(run.join("effects.log")).unwrap();
        match mode {
            "support-error" | "accepted-error" => {
                assert_eq!(output.status.code(), Some(4), "{mode}: {}", String::from_utf8_lossy(&output.stderr));
                assert!(!String::from_utf8_lossy(&output.stderr).contains("retry"));
                assert!(!effects.contains("ridley-root 0 0 1"), "error published after marker");
                assert_eq!(effects.lines().count(), usize::from(mode == "accepted-error"));
            }
            _ => assert!(output.status.success(), "{mode}: {}", String::from_utf8_lossy(&output.stderr)),
        }
        if mode == "mode7-order" {
            assert_eq!(
                effects.lines().collect::<Vec<_>>(),
                [
                    "ridley-write 8475 255",
                    "ridley-write 8475 254",
                    "ridley-write 8476 128",
                    "ridley-read 8501 52",
                    "ridley-read 8502 18"
                ]
            );
        }
        eprintln!("whole-Ridley compiled C control passed: {mode}");
    }
}

#[test]
fn actual_whole_rust_abi_controls_rom_guard_and_disjoint_buffers_without_callbacks() {
    let checkout = PathBuf::from(env!("CARGO_MANIFEST_DIR")).parent().unwrap().parent().unwrap().to_path_buf();
    let original = checkout.join("rom/sm.sfc");
    let execution = std::env::var_os("SM_RIDLEY_EXECUTION_ROM")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("/tmp/sm-ridley-whole-live-probe-9000-r5/ridley-execution.rom"));
    if !original.is_file() || !execution.is_file() {
        eprintln!("whole-Ridley ABI controls need local original and execution ROM; set SM_RIDLEY_EXECUTION_ROM");
        return;
    }
    let scratch = Scratch::new();
    let template = include_str!("../src/live_ridley_subsystem.rs.in")
        .replace("__ORIGINAL_ROM__", &format!("{original:?}"))
        .replace("__EXECUTION_ROM__", &format!("{execution:?}"));
    let source = format!(
        r#"
#[path={memory:?}]mod memory;use memory::*;
{template}
#[unsafe(no_mangle)]extern "C" fn PortWholeRidleyPublish(_: *const u8,_:*const u16){{panic!("support/refusal published state");}}
#[unsafe(no_mangle)]extern "C" fn PortWholeRidleyService(_: *mut u8,_:*mut u16,_:u32,_:u16,_:u16)->i64{{panic!("support/refusal invoked service");}}
#[unsafe(no_mangle)]extern "C" fn PortWholeRidleyMode7(_:i16,_:u8)->u16{{panic!("support/refusal invoked bus");}}
#[unsafe(no_mangle)]extern "C" fn PortWholeRidleyOrdered(_:u32,_:u16,_:u16,_:u16){{panic!("support/refusal emitted effect");}}
#[unsafe(no_mangle)]extern "C" fn PortWholeRidleyAllocation(_:u32,_:u16,_:u16,_:u16){{panic!("support/refusal allocated");}}
#[unsafe(no_mangle)]extern "C" fn PortWholeRidleyOpcode(_:u32,_:u32,_:u32,_:u32,_:u32){{panic!("support/refusal emitted opcode");}}
fn main(){{
 use whole_ridley_live::port_ridley_subsystem_live as call;
 assert_eq!(whole_ridley_live::port_ridley_subsystem_live_controls(),13);
 let mut state=vec![0;WRAM_SIZE];let mut host=[0x4321u16;8];
 {{let mut ram=Wram::new(&mut state).unwrap();ram.set_word(0xf78,0xe13f);ram.set_byte(0xfa6,0xa6);ram.set_word(0x79f,6);}}
 let before=state.clone();let words=host;let sealed=std::fs::read({execution:?}).unwrap();
 for offset in [0x29659,0x2965b]{{let mut changed=sealed.clone();changed[offset]^=1;unsafe{{assert_eq!(call(state.as_mut_ptr(),WRAM_SIZE,changed.as_ptr(),changed.len(),host.as_mut_ptr(),8,6,0),-1);}}assert_eq!(state,before);assert_eq!(host,words);}}
 // ROM/WRAM and ROM/host overlaps must reject before any slice or callback.
 let mut combined=vec![0u16;sealed.len()/2+16];let ptr=combined.as_mut_ptr().cast::<u8>();let saved=combined.clone();
 unsafe{{
  assert_eq!(call(ptr,WRAM_SIZE,ptr,sealed.len(),host.as_mut_ptr(),8,6,0),-1);
  assert_eq!(call(state.as_mut_ptr(),WRAM_SIZE,ptr,sealed.len(),combined.as_mut_ptr(),8,6,0),-1);
  assert_eq!(call(state.as_mut_ptr(),WRAM_SIZE,sealed.as_ptr(),sealed.len()-1,host.as_mut_ptr(),8,6,0),-1);
 }}assert_eq!(combined,saved);assert_eq!(state,before);assert_eq!(host,words);
 println!("actual whole Rust ABI: 13 production controls, adjacent ROM guards and two disjoint-buffer controls passed");
}}
"#,
        memory = checkout.join("crates/port/src/lib.rs")
    );
    fs::write(scratch.0.join("control.rs"), source).unwrap();
    let compile = Command::new("rustc")
        .args(["--edition=2024", "-O", "-Awarnings"])
        .arg(scratch.0.join("control.rs"))
        .arg("-o")
        .arg(scratch.0.join("control"))
        .output()
        .unwrap();
    assert!(compile.status.success(), "{}", String::from_utf8_lossy(&compile.stderr));
    let output = Command::new(scratch.0.join("control")).output().unwrap();
    assert!(output.status.success(), "{}", String::from_utf8_lossy(&output.stderr));
    eprintln!("{}", String::from_utf8_lossy(&output.stdout));
}
