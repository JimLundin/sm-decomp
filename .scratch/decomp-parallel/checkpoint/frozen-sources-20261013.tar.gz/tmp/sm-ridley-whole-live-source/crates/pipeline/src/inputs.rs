//! Compiler inputs and conservative module discovery for legacy family wrappers.
use crate::{atomic_toml, digest};
use anyhow::{Context, Result, ensure};
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, BTreeSet},
    fs,
    path::{Path, PathBuf},
};

#[derive(Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct WrapperRequest {
    pub checkout: PathBuf,
    pub run: PathBuf,
    pub modules: Vec<PathBuf>,
    pub imports: Vec<String>,
}
#[derive(Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub(crate) struct DependenciesRequest {
    pub checkout: PathBuf,
    pub run: PathBuf,
    pub extra: Vec<PathBuf>,
}
#[derive(Debug, Deserialize, Serialize)]
pub(crate) struct WrapperResult {
    pub path: PathBuf,
}

pub fn wrapper(request: WrapperRequest) -> Result<WrapperResult> {
    let checkout = fs::canonicalize(request.checkout)?;
    let run = fs::canonicalize(request.run)?;
    let sources = checkout.join("crates/port/src");
    let mut available = BTreeMap::new();
    for entry in fs::read_dir(&sources)? {
        let p = entry?.path();
        if p.extension().and_then(|v| v.to_str()) != Some("rs") {
            continue;
        }
        let name = p.file_stem().context("source stem missing")?.to_string_lossy().into_owned();
        if name != "lib" && name != "memory" {
            available.insert(name, p);
        }
    }
    let mut pending: Vec<PathBuf> = request.modules.iter().map(fs::canonicalize).collect::<std::io::Result<_>>()?;
    let mut selected = BTreeSet::new();
    for name in request.imports {
        pending.push(available.get(&name).context("unknown gameplay import")?.clone());
        selected.insert(name);
    }
    let mut visited = BTreeSet::new();
    while let Some(p) = pending.pop() {
        if !visited.insert(p.clone()) {
            continue;
        }
        let source = fs::read_to_string(&p)?;
        let mut child_names = BTreeSet::new();
        let mut child_pending = false;
        let mut lexical = String::new();
        for line in source.lines() {
            let trimmed = line.trim();
            if child_pending {
                if let Some((_, tail)) = trimmed.split_once("mod ") {
                    let name =
                        tail.split(|c: char| !(c.is_ascii_alphanumeric() || c == '_')).next().unwrap_or_default();
                    if !name.is_empty() {
                        child_names.insert(name.to_owned());
                    }
                }
                child_pending = false;
            }
            if trimmed.starts_with("#[path")
                && let Some((_, tail)) = trimmed.split_once('"')
                && let Some((child, _)) = tail.split_once('"')
            {
                // A path child shares its parent's namespace. Scan its
                // imports recursively without installing it at crate root.
                pending.push(fs::canonicalize(p.parent().context("module parent missing")?.join(child))?);
                child_pending = true;
                continue;
            }
            lexical.push_str(line);
            lexical.push('\n');
        }
        for word in lexical.split(|c: char| !(c.is_ascii_alphanumeric() || c == '_')) {
            if !child_names.contains(word)
                && let Some(module) = available.get(word)
                && selected.insert(word.to_owned())
            {
                pending.push(module.clone());
            }
        }
    }
    let memory = sources.join("memory.rs");
    let mut output = format!(
        "#[path={:?}] mod canonical;\npub use canonical::*;\n",
        memory.to_str().context("non-UTF8 source path")?
    );
    for name in selected {
        output.push_str(&format!(
            "#[path={:?}] pub mod {name};\n",
            available[&name].to_str().context("non-UTF8 source path")?
        ));
    }
    let destination = run.join("memory.rs");
    fs::write(&destination, output)?;
    Ok(WrapperResult { path: destination })
}

pub(crate) fn dep_paths(text: &str) -> Result<Vec<String>> {
    let joined = text.replace("\\\n", "");
    let rule =
        joined.split_once(": ").context("invalid compiler dependency rule")?.1.lines().next().unwrap_or_default();
    let mut result = Vec::new();
    let mut token = String::new();
    let mut escaped = false;
    for c in rule.chars() {
        if escaped {
            token.push(c);
            escaped = false;
        } else if c == '\\' {
            escaped = true;
        } else if c.is_whitespace() {
            if !token.is_empty() {
                result.push(std::mem::take(&mut token));
            }
        } else {
            token.push(c);
        }
    }
    ensure!(!escaped, "truncated compiler dependency escape");
    if !token.is_empty() {
        result.push(token);
    }
    Ok(result)
}

pub fn dependencies(request: DependenciesRequest) -> Result<BTreeMap<String, String>> {
    let checkout = fs::canonicalize(request.checkout)?;
    let run = fs::canonicalize(request.run)?;
    let mut paths = BTreeSet::new();
    for name in dep_paths(&fs::read_to_string(run.join("compiler.d"))?)? {
        let p = Path::new(&name);
        paths.insert(fs::canonicalize(if p.is_absolute() { p.to_path_buf() } else { run.join(p) })?);
    }
    for p in &request.extra {
        paths.insert(fs::canonicalize(if p.is_absolute() { p.to_path_buf() } else { checkout.join(p) })?);
    }
    let mut result = BTreeMap::new();
    for (index, p) in paths.into_iter().enumerate() {
        if p.starts_with(&run) {
            continue;
        }
        let key = p.strip_prefix(&checkout).unwrap_or(&p).to_string_lossy().into_owned();
        result.insert(key, digest(&p)?);
        fs::copy(&p, run.join(format!("dependency-{index:03}.rs")))?;
    }
    // Keep the tool identity alongside the source inventory, so changing the
    // discovery algorithm cannot silently admit an older dependency contract.
    let mut tools = BTreeMap::new();
    for (name, compiled) in [
        ("main.rs", include_str!("main.rs")),
        ("inputs.rs", include_str!("inputs.rs")),
        ("builds.rs", include_str!("builds.rs")),
    ] {
        let key = format!("crates/pipeline/src/{name}");
        let hash = digest(&checkout.join(&key))?;
        ensure!(
            hash == format!("{:x}", <sha2::Sha256 as sha2::Digest>::digest(compiled.as_bytes())),
            "pipeline executable is stale: {name}"
        );
        result.insert(key.clone(), hash.clone());
        tools.insert(key, hash);
        fs::copy(checkout.join(format!("crates/pipeline/src/{name}")), run.join(format!("pipeline-{name}")))?;
    }
    #[derive(Serialize)]
    struct PipelineInputs<'a> {
        binary_sha256: &'a str,
        sources: BTreeMap<String, String>,
    }
    atomic_toml(
        &run.join("pipeline-inputs.toml"),
        &PipelineInputs { binary_sha256: crate::binary_digest()?, sources: tools },
    )?;
    Ok(result)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn path_children_keep_parent_namespace_and_scan_relative_transitive_imports() {
        let root = std::env::temp_dir().join(format!(
            "sm-wrapper-path-{}-{}",
            std::process::id(),
            std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos()
        ));
        let sources = root.join("crates/port/src");
        let run = root.join("run");
        fs::create_dir_all(sources.join("private")).unwrap();
        fs::create_dir(&run).unwrap();
        for (name, source) in [
            ("memory.rs", "pub struct Wram;"),
            (
                "parent.rs",
                "#[path = \"private/child.rs\"]\nmod collision;\nuse crate::direct;\nfn run(){collision::run();}",
            ),
            ("private/child.rs", "use super::*;\n#[path = \"grandchild.rs\"]\nmod nested;\nuse crate::transitive;"),
            ("private/grandchild.rs", "use crate::deep;"),
            ("collision.rs", "compile_error!(\"path child must not install this unrelated root collision\");"),
            ("direct.rs", ""),
            ("transitive.rs", ""),
            ("deep.rs", ""),
        ] {
            fs::write(sources.join(name), source).unwrap();
        }
        let result = wrapper(WrapperRequest {
            checkout: root.clone(),
            run: run.clone(),
            modules: vec![sources.join("parent.rs")],
            imports: vec!["parent".into()],
        })
        .unwrap();
        let generated = fs::read_to_string(result.path).unwrap();
        for name in ["parent", "direct", "transitive", "deep"] {
            assert!(generated.contains(&format!("pub mod {name};")));
        }
        assert!(!generated.contains("pub mod collision;"));
        assert!(!generated.contains("pub mod nested;"));
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn parses_compiler_rules_with_spaces_and_continuations() {
        assert_eq!(
            dep_paths("out: /a/source.rs /a/with\\ space.rs \\\n /last.rs\nother: /ignored.rs\n").unwrap(),
            vec!["/a/source.rs", "/a/with space.rs", "/last.rs"]
        );
        assert!(dep_paths("missing rule").is_err());
    }
}
