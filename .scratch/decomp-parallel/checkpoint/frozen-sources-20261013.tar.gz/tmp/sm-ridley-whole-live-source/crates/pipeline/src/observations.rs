//! Authenticate retained observations using their sealed Rust reader executable.
use crate::{acquire_lease, digest};
use anyhow::{Context, Result, ensure};
use evidence::{Inventory, Pointer};
use serde::{Deserialize, Serialize};
#[derive(Deserialize, Serialize)]
pub struct AuthenticateRequest {
    pub verdict: std::path::PathBuf,
    pub root: std::path::PathBuf,
    pub workers: usize,
}
#[derive(Deserialize, Serialize)]
pub struct AuthenticationReceipt {
    pub status: String,
    pub artifacts_per_subject: usize,
    pub subjects: usize,
    pub binary: bool,
    pub storage: String,
    pub verdict_sha256: String,
    pub scope: String,
}
#[derive(Deserialize)]
struct SealedSubject {
    pointer_sha256: String,
    run: String,
    observations: String,
}
#[derive(Deserialize)]
struct EvidenceStorage {
    format: String,
    subjects: BTreeMap<String, SealedSubject>,
}
#[derive(Deserialize)]
struct Verdict {
    state_effects_match: bool,
    artifacts: BTreeMap<String, String>,
    binary_sha256: String,
    evidence_reader_sha256: String,
    evidence_storage: EvidenceStorage,
    #[serde(default)]
    projectile_native_installed: bool,
    projectile_abi: Option<String>,
    #[serde(default)]
    frames: u64,
    #[serde(default)]
    counters: BTreeMap<String, crate::live_model::Counters>,
    #[serde(default)]
    routine_symbols: Vec<String>,
    #[serde(default)]
    bounded_symbols: BTreeSet<String>,
    #[serde(default)]
    ridley_native_installed: bool,
    #[serde(default)]
    ridley_subsystem_installed: bool,
    #[serde(default)]
    ridley_execution_rom_sha256: Option<String>,
}
use std::{
    collections::{BTreeMap, BTreeSet},
    fs::{self},
    path::Path,
    process::Command,
};
const SUBJECTS: [&str; 4] = ["c-0", "c-1", "mixed-0", "mixed-1"];

fn document<T: serde::de::DeserializeOwned>(path: &Path) -> Result<T> {
    ensure!(!path.is_symlink(), "evidence document is a symlink");
    Ok(toml::from_str(&fs::read_to_string(path)?)?)
}
pub fn subject(directory: &Path, root: &Path, workers: usize, expected_pointer: Option<&str>) -> Result<Pointer> {
    let context = crate::metrics::active();
    subject_with_metrics(directory, root, workers, expected_pointer, context.as_ref())
}
pub(crate) fn subject_with_metrics(
    directory: &Path,
    root: &Path,
    workers: usize,
    expected_pointer: Option<&str>,
    metrics: Option<&crate::metrics::Context>,
) -> Result<Pointer> {
    ensure!(!directory.is_symlink(), "subject directory is a symlink");
    let pointer_path = directory.join("evidence.toml");
    if let Some(expected) = expected_pointer {
        ensure!(digest(&pointer_path)? == expected, "subject pointer changed");
    }
    let pointer: Pointer = document(&pointer_path)?;
    ensure!(pointer.format == "sm-evidence-v2", "unknown evidence format");
    let store_path = directory.join(pointer.store.as_ref().context("pointer store missing")?);
    ensure!(!store_path.is_symlink(), "evidence store is a symlink");
    let store = fs::canonicalize(store_path)?;
    let reader = directory.parent().context("subject parent missing")?.join("sm-evidence");
    let expected = pointer.provenance.reader_sha256.as_deref().context("reader digest missing")?;
    ensure!(!reader.is_symlink() && digest(&reader)? == expected, "retained evidence reader changed");
    let waiting = metrics.map(|metrics| metrics.stage("authentication-worker-wait")).transpose()?;
    let (_held, _wait) = acquire_lease(root, workers)?;
    if let Some(waiting) = waiting {
        waiting.finish("success")?;
    }
    let mut command = Command::new(reader);
    command.arg("inventory").arg(store).arg(&pointer.run);
    let output = if let Some(metrics) = metrics {
        let sidecar = crate::metrics::sidecar(directory, "authentication");
        let context = metrics.child_context(&mut command, &sidecar, "authentication")?;
        let output = metrics.output(&mut command, "subject-authentication")?;
        metrics.merge_child(&sidecar)?;
        fs::remove_file(context)?;
        output
    } else {
        command.output()?
    };
    ensure!(
        output.status.success(),
        "packed evidence authentication failed: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let actual: Inventory = toml::from_str(std::str::from_utf8(&output.stdout)?)?;
    ensure!(
        actual.observations == pointer.observations
            && actual.files == pointer.files
            && actual.bytes == pointer.bytes
            && actual.artifacts == pointer.artifacts
            && actual.provenance == pointer.provenance,
        "packed evidence inventory differs"
    );
    Ok(pointer)
}

pub fn authenticate(request: AuthenticateRequest) -> Result<AuthenticationReceipt> {
    let path = &request.verdict;
    let verdict: Verdict = document(path)?;
    let run = path.parent().context("verdict parent missing")?;
    ensure!(verdict.state_effects_match && !verdict.artifacts.is_empty(), "no finished matching observation inventory");
    let binary = run.join("live");
    ensure!(!binary.is_symlink() && digest(&binary)? == verdict.binary_sha256, "retained live binary changed");
    let packed = &verdict.evidence_storage;
    ensure!(packed.format == "sm-evidence-v2", "unknown packed format");
    ensure!(
        packed.subjects.len() == 4 && SUBJECTS.iter().all(|name| packed.subjects.contains_key(*name)),
        "packed subjects incomplete"
    );
    ensure!(digest(&run.join("sm-evidence"))? == verdict.evidence_reader_sha256, "retained evidence reader changed");
    for name in SUBJECTS {
        let sealed = &packed.subjects[name];
        let pointer = subject(&run.join(name), &request.root, request.workers, Some(&sealed.pointer_sha256))?;
        let expected = pointer
            .artifacts
            .iter()
            .filter(|(name, _)| {
                Path::new(name).file_name().is_none_or(|v| v != "calls.bin")
                    && Path::new(name).extension().is_none_or(|v| v != "rom")
            })
            .map(|(name, value)| (name.clone(), value.clone()))
            .collect::<BTreeMap<_, _>>();
        ensure!(
            expected == verdict.artifacts && pointer.run == sealed.run && pointer.observations == sealed.observations,
            "packed observations differ from verdict"
        );
        ensure!(
            pointer.provenance.binary_sha256.as_deref() == Some(verdict.binary_sha256.as_str())
                && pointer.provenance.subject.as_deref() == Some(name),
            "packed producer provenance differs"
        );
    }
    if verdict.projectile_native_installed || !verdict.bounded_symbols.is_empty() || verdict.ridley_subsystem_installed
    {
        let has_bounded = !verdict.bounded_symbols.is_empty();
        ensure!(
            !verdict.ridley_native_installed
                || (verdict.projectile_native_installed
                    && verdict.bounded_symbols.contains("ProcessEnemyInstructions")),
            "Ridley frame dependencies incomplete"
        );
        if has_bounded {
            ensure!(
                verdict.routine_symbols.iter().collect::<BTreeSet<_>>().len() == verdict.routine_symbols.len(),
                "duplicate retained generation symbols"
            );
        }
        for name in SUBJECTS {
            let recorded = verdict.counters.get(name).context("missing native subject counters")?;
            let historical_symbols;
            let symbols = if has_bounded || !verdict.routine_symbols.is_empty() {
                &verdict.routine_symbols
            } else {
                // Historical projectile verdicts did not retain generation order.
                // Only their named projectile counters and progress are compared.
                historical_symbols = recorded.hits.keys().cloned().collect::<Vec<_>>();
                &historical_symbols
            };
            let actual = crate::live::counters(&run.join(name), symbols, name.split('-').next().unwrap())?;
            ensure!(
                actual.projectile_hits == recorded.projectile_hits
                    && actual.projectile_id_hits == recorded.projectile_id_hits
                    && actual.projectile_allocation_hits == recorded.projectile_allocation_hits
                    && actual.progress == recorded.progress,
                "native projectile counters differ from retained stdout"
            );
            if has_bounded || verdict.ridley_subsystem_installed {
                ensure!(actual == *recorded, "bounded frame counters differ from retained stdout");
            }
        }
    }
    if verdict.projectile_native_installed {
        ensure!(
            verdict.projectile_abi.as_deref() == Some("synchronous-eight-word-host-v2-with-gfx"),
            "unknown native projectile ABI"
        );
        crate::live::projectile_admission(&verdict.counters, &verdict.artifacts, verdict.frames)?;
    }
    if !verdict.bounded_symbols.is_empty() {
        crate::live::frame_admission(&verdict.counters, &verdict.artifacts, &verdict.bounded_symbols, verdict.frames)?;
    }
    if verdict.ridley_subsystem_installed {
        ensure!(
            verdict.projectile_native_installed
                && !verdict.ridley_native_installed
                && verdict.ridley_execution_rom_sha256.as_deref()
                    == Some("40aaebb25b9646bea2dffdc5e1ae680768a39dd122de9353885e1c7456ceae27"),
            "whole Ridley dependencies/ROM contract differs"
        );
        crate::live::whole_ridley_admission(&verdict.counters, &verdict.artifacts)?;
    }
    Ok(AuthenticationReceipt {
        status: "authenticated".into(),
        artifacts_per_subject: verdict.artifacts.len(),
        subjects: 4,
        binary: true,
        storage: "sm-evidence-v2".into(),
        verdict_sha256: digest(path)?,
        scope: "retained frozen binary and observations; current-source admission and original-ROM parity separate"
            .into(),
    })
}
