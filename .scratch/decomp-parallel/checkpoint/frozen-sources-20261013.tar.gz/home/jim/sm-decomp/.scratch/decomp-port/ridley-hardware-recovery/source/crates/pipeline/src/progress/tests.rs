use super::*;

struct Scratch(PathBuf);
impl Scratch {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "sm-progress-test-{}-{}",
            std::process::id(),
            NEXT_FILE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir(&path).unwrap();
        Self(path)
    }
    fn options(&self) -> Options {
        Options {
            root: self.0.clone(),
            registry: self.0.join("registry.json"),
            html: self.0.join("index.html"),
            source: None,
            update: None,
            bind: "127.0.0.1:0".parse().unwrap(),
        }
    }
}
impl Drop for Scratch {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).unwrap();
    }
}
fn registry(root: &Path) -> Registry {
    Registry {
        schema_version: 1,
        root: root.to_string_lossy().into_owned(),
        updated_at: 1,
        source: Source {
            revision: "a".repeat(40),
            inventory_sha256: "b".repeat(64),
            identity_sha256: "c".repeat(64),
            definition_count: 2,
            body_lines: 30,
            scope: "all pinned definitions".into(),
            source_root: None,
            source_verified_at: None,
        },
        routines: ["First", "Second"]
            .into_iter()
            .enumerate()
            .map(|(index, symbol)| Routine {
                symbol: symbol.into(),
                source: "src/sm_80.c".into(),
                line: index + 1,
                original_address: None,
                body_lines: (index + 1) * 10,
                definition_sha256: "d".repeat(64),
                calls: Vec::new(),
                declared_in: vec!["tools/port/declared.toml".into()],
            })
            .collect(),
        updates: Vec::new(),
        notices: Vec::new(),
        stale_update_ids: Vec::new(),
        summary: Summary::default(),
    }
}
fn observation(root: &Path, id: &str, symbol: &str, stage: Stage) -> Update {
    let evidence = root.join("evidence.txt");
    if !evidence.exists() {
        fs::write(&evidence, b"retained evidence").unwrap();
    }
    Update {
        id: id.into(),
        scope: "camera scroll ownership".into(),
        agent: "worker".into(),
        stage,
        routines: vec![symbol.into()],
        source_revision: "a".repeat(40),
        inventory_sha256: "b".repeat(64),
        commit: Some("e".repeat(40)),
        evidence: vec![Evidence { path: "evidence.txt".into(), sha256: crate::digest(&evidence).unwrap() }],
        limitations: vec!["offline scope only; no gameplay acceptance".into()],
        updated_at: 2,
    }
}

fn inventory_root(root: &Path) {
    fs::create_dir_all(root.join("tools/port")).unwrap();
    fs::write(
        root.join("tools/dependencies.toml"),
        format!(
            "[[dependencies]]\nname = 'snesrev-sm'\nrevision = '{}'\nsha256 = '{}'\n",
            "a".repeat(40),
            "c".repeat(64)
        ),
    )
    .unwrap();
    fs::write(
        root.join(INVENTORY),
        format!(
            "schema_version = 1\ndefinition_count = 1\nscope = 'all sm_*.c definitions'\n\
         [source_identity]\nrevision = '{}'\narchive_sha256 = '{}'\nfreshness = 'pinned archive'\n\
         [source_identity.files]\n'src/sm_80.c' = '{}'\n\
         [banks.'src/sm_80.c']\ndefinitions = 1\nbody_lines = 10\n\
         [[routines]]\nsymbol = 'First'\nsource = 'src/sm_80.c'\nline = 1\n\
         signature = 'void First(void)'\nbody_lines = 10\ndefinition_sha256 = '{}'\n\
         calls = []\nindirect_indexed_calls = []\ndefined_dependencies = []\n\
         external_or_macro_calls = []\ntranslation_status = 'unverified'\n",
            "a".repeat(40),
            "c".repeat(64),
            "d".repeat(64),
            "e".repeat(64)
        ),
    )
    .unwrap();
    fs::write(
        root.join("tools/port/declared.toml"),
        "family = 'declaration'\n[[routines]]\nsymbol = 'First'\n[[routines]]\nsymbol = 'HostWrapper'\n",
    )
    .unwrap();
}

#[test]
fn declarations_skip_large_fixture_payloads_and_preserve_symbols() {
    let scratch = Scratch::new();
    fs::create_dir_all(scratch.0.join("tools/port")).unwrap();
    let mut manifest = String::from(
        "family = 'large'\n[[routines]]\nsymbol = 'First'\n[[routines.cases]]\ndata = [\n",
    );
    for _ in 0..2_000_000 {
        manifest.push_str("0,");
    }
    manifest.push_str("\n]\n[[routines]]\nsymbol = 'First'\n[[routines]]\nsymbol = 'Unknown'\n");
    fs::write(scratch.0.join("tools/port/large.toml"), manifest).unwrap();
    let mut routines = registry(&scratch.0).routines;
    let mut notices = Vec::new();
    let started = Instant::now();
    add_declarations(&scratch.0, &mut routines, &mut notices).unwrap();
    let elapsed = started.elapsed();
    assert_eq!(routines[0].declared_in, ["tools/port/large.toml"]);
    assert!(routines[1].declared_in.is_empty());
    assert_eq!(notices, ["Declaration tools/port/large.toml names Unknown outside the C inventory; it contributes no C coverage."]);
    eprintln!("four-megabyte progress declaration scan: {elapsed:?}");
    assert!(elapsed < Duration::from_secs(2), "progress decoded fixture payloads: {elapsed:?}");
}

#[test]
fn refresh_covers_inventory_and_validates_pin_and_definition_totals() {
    let scratch = Scratch::new();
    inventory_root(&scratch.0);
    let options = scratch.options();
    let first = refresh(&options).unwrap();
    assert_eq!(first.routines.len(), 1);
    assert_eq!(first.summary.declared_definitions, 1);
    assert!(first.summary.stages.values().all(|c| c.definitions == 0));
    assert!(first.notices.iter().any(|v| v.contains("HostWrapper")));
    assert!(options.html.exists());
    let original = fs::read_to_string(scratch.0.join(INVENTORY)).unwrap();
    fs::write(scratch.0.join(INVENTORY), original.replacen("definition_count = 1", "definition_count = 2", 1)).unwrap();
    assert!(refresh(&options).unwrap_err().to_string().contains("definition count differs"));
    assert_eq!(read_registry(&options).unwrap().routines.len(), 1);
    fs::write(scratch.0.join(INVENTORY), original.replace(&"a".repeat(40), &"b".repeat(40))).unwrap();
    assert!(refresh(&options).unwrap_err().to_string().contains("pinned C source"));
}

#[test]
fn inventory_refresh_retains_historical_stage_observations_without_current_coverage() {
    let scratch = Scratch::new();
    inventory_root(&scratch.0);
    let options = scratch.options();
    let mut current = refresh(&options).unwrap();
    let mut update = observation(&scratch.0, "historical", "First", Stage::Verified);
    update.source_revision = current.source.revision.clone();
    update.inventory_sha256 = current.source.inventory_sha256.clone();
    insert_update(&mut current, update.clone()).unwrap();
    observe_evidence(&scratch.0, &mut current).unwrap();
    persist(&options, &current).unwrap();
    assert_eq!(current.summary.stages["verified"].definitions, 1);
    let inventory = scratch.0.join(INVENTORY);
    let bytes = fs::read_to_string(&inventory)
        .unwrap()
        .replace("scope = 'all sm_*.c definitions'", "scope = 'corrected lexical inventory'");
    fs::write(inventory, bytes).unwrap();
    let refreshed = refresh(&options).unwrap();
    assert_eq!(refreshed.updates, [update]);
    assert_eq!(refreshed.stale_update_ids, ["historical"]);
    assert_eq!(refreshed.summary.stages["verified"].definitions, 0);
    assert!(refreshed.notices.iter().any(|notice| notice.contains("source inventory changed")));
}

#[test]
fn update_command_rechecks_retained_evidence_and_source_before_publication() {
    let scratch = Scratch::new();
    inventory_root(&scratch.0);
    let mut options = scratch.options();
    let initial = refresh(&options).unwrap();
    fs::write(scratch.0.join("evidence.txt"), b"retained evidence").unwrap();
    let path = scratch.0.join("update.toml");
    let payload = format!(
        "id = 'scope-one-translated'\nscope = 'camera scroll ownership'\nagent = 'worker'\n\
         stage = 'translated'\nroutines = ['First']\nsource_revision = '{}'\n\
         inventory_sha256 = '{}'\nlimitations = ['offline only']\n\
         [[evidence]]\npath = 'evidence.txt'\nsha256 = '{}'\n",
        initial.source.revision,
        initial.source.inventory_sha256,
        crate::digest(&scratch.0.join("evidence.txt")).unwrap()
    );
    fs::write(&path, &payload).unwrap();
    options.update = Some(path.clone());
    assert_eq!(update(&options).unwrap().summary.stages["translated"].definitions, 1);
    assert_eq!(update(&options).unwrap().updates.len(), 1);
    fs::write(
        &path,
        payload.replace("['First']", "['Unknown']").replace("scope-one-translated", "scope-two-translated"),
    )
    .unwrap();
    assert!(update(&options).unwrap_err().to_string().contains("unknown C routine"));
    fs::write(&path, &payload).unwrap();
    fs::write(scratch.0.join("evidence.txt"), b"changed evidence").unwrap();
    assert!(update(&options).unwrap_err().to_string().contains("evidence digest differs"));
    assert_eq!(read_registry(&options).unwrap().updates.len(), 1);
}

#[test]
fn stages_are_independent_and_declarations_do_not_grant_progress() {
    let scratch = Scratch::new();
    let mut registry = registry(&scratch.0);
    observe_evidence(&scratch.0, &mut registry).unwrap();
    assert_eq!(registry.summary.declared_definitions, 2);
    assert!(registry.summary.stages.values().all(|c| c.definitions == 0));
    insert_update(&mut registry, observation(&scratch.0, "one", "First", Stage::Translated)).unwrap();
    insert_update(&mut registry, observation(&scratch.0, "two", "Second", Stage::Integrated)).unwrap();
    observe_evidence(&scratch.0, &mut registry).unwrap();
    assert_eq!(registry.summary.stages["translated"].definitions, 1);
    assert_eq!(registry.summary.stages["integrated"].definitions, 1);
    assert_eq!(registry.summary.stages["verified"].definitions, 0);
    assert_eq!(registry.summary.stages["live-exercised"].definitions, 0);
}

#[test]
fn idempotent_retry_preserves_timestamp_and_conflicting_id_is_rejected() {
    let scratch = Scratch::new();
    let mut registry = registry(&scratch.0);
    let update = observation(&scratch.0, "one", "First", Stage::Translated);
    assert!(insert_update(&mut registry, update.clone()).unwrap());
    let mut retry = update.clone();
    retry.updated_at = 100;
    assert!(!insert_update(&mut registry, retry).unwrap());
    assert_eq!(registry.updates.len(), 1);
    assert_eq!(registry.updates[0].updated_at, 2);
    let mut conflict = update;
    conflict.stage = Stage::Verified;
    assert!(insert_update(&mut registry, conflict).unwrap_err().to_string().contains("conflicting"));
}

#[test]
fn stale_source_unknown_symbols_and_missing_evidence_are_rejected() {
    let scratch = Scratch::new();
    let mut registry = registry(&scratch.0);
    let unknown = observation(&scratch.0, "one", "Unknown", Stage::Translated);
    assert!(insert_update(&mut registry, unknown).unwrap_err().to_string().contains("unknown C routine"));
    let mut stale = observation(&scratch.0, "two", "First", Stage::Translated);
    stale.inventory_sha256 = "f".repeat(64);
    assert!(insert_update(&mut registry, stale).unwrap_err().to_string().contains("stale"));
    assert!(evidence_path(&scratch.0, "absent.txt").is_err());
    assert!(evidence_path(&scratch.0, "../evidence.txt").is_err());
    insert_update(&mut registry, observation(&scratch.0, "three", "First", Stage::Verified)).unwrap();
    fs::write(scratch.0.join("evidence.txt"), b"changed after publication").unwrap();
    observe_evidence(&scratch.0, &mut registry).unwrap();
    assert_eq!(registry.summary.stale_updates, 1);
    assert_eq!(registry.summary.stages["verified"].definitions, 0);
    assert!(registry.notices.iter().any(|v| v.contains("evidence changed")));
    registry.source.inventory_sha256 = "f".repeat(64);
    observe_evidence(&scratch.0, &mut registry).unwrap();
    assert!(registry.notices.iter().any(|v| v.contains("source inventory changed")));
}

#[test]
fn concurrent_writers_preserve_scope_observations_and_valid_json() {
    let scratch = Scratch::new();
    let options = scratch.options();
    fs::write(scratch.0.join("evidence.txt"), b"retained evidence").unwrap();
    persist(&options, &registry(&scratch.0)).unwrap();
    let handles = (0..6)
        .map(|index| {
            let options = options.clone();
            std::thread::spawn(move || {
                let _lock = registry_lock(&options.registry, Duration::from_secs(3)).unwrap();
                let mut registry = read_registry(&options).unwrap();
                let mut update = observation(&options.root, &format!("agent-{index}"), "First", Stage::Translating);
                update.scope = format!("scope-{index}");
                update.agent = format!("agent-{index}");
                insert_update(&mut registry, update).unwrap();
                observe_evidence(&options.root, &mut registry).unwrap();
                persist(&options, &registry).unwrap();
            })
        })
        .collect::<Vec<_>>();
    for handle in handles {
        handle.join().unwrap();
    }
    let registry = read_registry(&options).unwrap();
    assert_eq!(registry.updates.len(), 6);
    assert_eq!(registry.summary.stages["translating"].definitions, 1);
    assert_eq!(registry.updates.iter().map(|u| &u.scope).collect::<BTreeSet<_>>().len(), 6);
    assert!(options.registry.with_extension("json.lock").exists());
    assert!(fs::read_to_string(options.html).unwrap().contains("agent-5"));
}

#[test]
fn contention_is_bounded_and_lock_releases_after_owner_exit() {
    let scratch = Scratch::new();
    let path = scratch.0.join("registry.json");
    let lock = registry_lock(&path, Duration::from_secs(1)).unwrap();
    assert!(registry_lock(&path, Duration::from_millis(30)).unwrap_err().to_string().contains("timed out"));
    drop(lock);
    registry_lock(&path, Duration::from_millis(30)).unwrap();
}

#[test]
fn malformed_updates_and_unsafe_embedding_are_handled() {
    let scratch = Scratch::new();
    let mut registry = registry(&scratch.0);
    let mut update = observation(&scratch.0, "one", "First", Stage::Integrated);
    update.commit = None;
    assert!(validate_update_shape(&update).is_err());
    assert!(toml::from_str::<UpdateInput>("id = 'one'\nstage = 'accepted'\n").is_err());
    assert!(options("status", &["--unexpected".into(), "value".into()]).is_err());
    registry.notices.push("</script><script>untrusted()</script>".into());
    let html = render(&registry).unwrap();
    assert!(!html.contains("</script><script>untrusted()"));
    assert!(html.contains("\\u003c/script>"));
}

#[test]
fn server_routes_only_bounded_gets_without_directory_access() {
    assert_eq!(request_target(b"GET /registry.json?time=1 HTTP/1.1\r\n\r\n").unwrap(), "/registry.json");
    assert!(request_target(b"POST /registry.json HTTP/1.1\r\n\r\n").is_err());
    assert!(request_target(b"GET / HTTP/1.1 extra\r\n\r\n").is_err());
    let bytes = response("200 OK", "application/json", b"{}");
    let response = String::from_utf8(bytes).unwrap();
    assert!(response.contains("Cache-Control: no-store\r\n"));
    assert!(response.contains("Content-Length: 2\r\n"));
}

#[test]
fn live_http_snapshot_excludes_changed_evidence_and_rejects_stale_inventory() {
    let scratch = Scratch::new();
    inventory_root(&scratch.0);
    let options = scratch.options();
    let mut registry = refresh(&options).unwrap();
    let mut update = observation(&scratch.0, "one", "First", Stage::Verified);
    update.source_revision = registry.source.revision.clone();
    update.inventory_sha256 = registry.source.inventory_sha256.clone();
    insert_update(&mut registry, update).unwrap();
    observe_evidence(&scratch.0, &mut registry).unwrap();
    persist(&options, &registry).unwrap();
    let request = |options: &Options, target: &str| {
        let listener = TcpListener::bind("127.0.0.1:0").unwrap();
        let addr = listener.local_addr().unwrap();
        let options = options.clone();
        let server = std::thread::spawn(move || {
            let (mut stream, _) = listener.accept().unwrap();
            respond(&mut stream, &options).unwrap();
        });
        let mut client = TcpStream::connect(addr).unwrap();
        client.write_all(format!("GET {target} HTTP/1.1\r\nHost: localhost\r\n\r\n").as_bytes()).unwrap();
        let mut text = String::new();
        client.read_to_string(&mut text).unwrap();
        server.join().unwrap();
        text
    };
    let current = request(&options, "/registry.json");
    let current: Registry = serde_json::from_str(current.split_once("\r\n\r\n").unwrap().1).unwrap();
    assert_eq!(current.summary.stages["verified"].definitions, 1);
    fs::write(scratch.0.join("evidence.txt"), b"changed").unwrap();
    let stale = request(&options, "/registry.json");
    let stale: Registry = serde_json::from_str(stale.split_once("\r\n\r\n").unwrap().1).unwrap();
    assert_eq!(stale.stale_update_ids, ["one"]);
    assert_eq!(stale.summary.stages["verified"].definitions, 0);
    assert!(request(&options, "/../evidence.txt").starts_with("HTTP/1.1 404"));
    fs::write(scratch.0.join(INVENTORY), b"changed inventory").unwrap();
    assert!(request(&options, "/registry.json").starts_with("HTTP/1.1 409"));
}
