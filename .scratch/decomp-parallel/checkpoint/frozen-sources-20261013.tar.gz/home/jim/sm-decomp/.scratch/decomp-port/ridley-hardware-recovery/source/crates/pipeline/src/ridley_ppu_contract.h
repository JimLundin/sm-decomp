// Exact Ridley hardware v2: active discriminator, both PPU Mode7/bus states,
// and SNES open bus. All fields are written as explicit little-endian bytes.
#ifndef RIDLEY_PPU_CONTRACT_H
#define RIDLEY_PPU_CONTRACT_H
#define RIDLEY_PPU_BYTES 40
static void RidleyPpuViewSave(uint8_t *bytes, const Ppu *ppu) {
  for (unsigned i = 0; i < 8; i++) {
    bytes[2*i] = (uint16_t)ppu->m7matrix[i];
    bytes[2*i+1] = (uint16_t)ppu->m7matrix[i] >> 8;
  }
  bytes[16] = ppu->m7prev;
  bytes[17] = ppu->ppu1openBus;
  bytes[18] = ppu->ppu2openBus;
}
static int RidleyPpuContractSave(uint8_t *bytes) {
  if (g_snes->ppu == g_snes->my_ppu) bytes[0] = 0;
  else if (g_snes->ppu == g_snes->snes_ppu) bytes[0] = 1;
  else return 0;
  RidleyPpuViewSave(bytes + 1, g_snes->my_ppu);
  RidleyPpuViewSave(bytes + 20, g_snes->snes_ppu);
  bytes[39] = g_snes->openBus;
  return 1;
}
static void RidleyPpuViewLoad(Ppu *ppu, const uint8_t *bytes) {
  for (unsigned i = 0; i < 8; i++)
    ppu->m7matrix[i] = (int16_t)((uint16_t)bytes[2*i] | ((uint16_t)bytes[2*i+1] << 8));
  ppu->m7prev = bytes[16];
  ppu->ppu1openBus = bytes[17];
  ppu->ppu2openBus = bytes[18];
}
static int RidleyPpuContractLoad(const uint8_t *bytes) {
  if (bytes[0] > 1) return 0;
  RidleyPpuViewLoad(g_snes->my_ppu, bytes + 1);
  RidleyPpuViewLoad(g_snes->snes_ppu, bytes + 20);
  g_snes->openBus = bytes[39];
  g_snes->ppu = bytes[0] ? g_snes->snes_ppu : g_snes->my_ppu;
  return 1;
}
#endif
